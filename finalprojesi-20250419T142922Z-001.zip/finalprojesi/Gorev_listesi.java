package com.example.finalprojesi;

public class Gorev_listesi {

    private int id;
    private String gorev_ismi;
    private String gorev_aciklamasi;
    private String onem_duzeyi;
    private String durum;

    public Gorev_listesi(int id, String gorev_ismi, String gorev_aciklamasi, String onem_duzeyi, String durum) {
        this.id = id;
        this.gorev_ismi=gorev_ismi;
        this.gorev_aciklamasi=gorev_aciklamasi;
        this.onem_duzeyi=onem_duzeyi;
        this.durum=durum;
    }

    public Gorev_listesi(String gorev_ismi, String gorev_aciklamasi, String onem_duzeyi, String durum) {
        this.gorev_ismi=gorev_ismi;
        this.gorev_aciklamasi=gorev_aciklamasi;
        this.onem_duzeyi=onem_duzeyi;
        this.durum=durum;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getGorev_ismi() {
        return gorev_ismi;
    }

    public void setGorev_ismi(String gorev_ismi) {
        this.gorev_ismi=gorev_ismi;
    }

    public String getGorev_aciklamasi() {
        return gorev_aciklamasi;
    }

    public void setGorev_aciklamasi(String gorev_aciklamasi) {
        this.gorev_aciklamasi=gorev_aciklamasi;
    }

    public String getOnem_duzeyi() {
        return onem_duzeyi;
    }

    public void setOnem_duzeyi(String onem_duzeyi) {
        this.onem_duzeyi=onem_duzeyi;
    }

    public String getDurum() {
        return durum;
    }

    public void setDurum(String durum) {
        this.durum = durum;
    }
}
