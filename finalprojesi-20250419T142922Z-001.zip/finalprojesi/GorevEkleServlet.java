package com.example.finalprojesi;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(name = "GorevEkleServlet", value = "/gorevEkle")
public class GorevEkleServlet extends HttpServlet {

    private Gorev_listesiVeri gorev_listesiVeri = new Gorev_listesiVeri();

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

        try {
            String gorev_ismi = request.getParameter("gorev_ismi");
            String gorev_aciklamasi = request.getParameter("gorev_aciklamasi");
            String onem_duzeyi = request.getParameter("onem_duzeyi");
            String durum = request.getParameter("durum");


            Gorev_listesi gorev1 = new Gorev_listesi(gorev_ismi,gorev_aciklamasi,onem_duzeyi,durum);

            gorev_listesiVeri.gorevEkle(gorev1);

            response.sendRedirect(request.getContextPath()+"/index");


        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }


    }
}