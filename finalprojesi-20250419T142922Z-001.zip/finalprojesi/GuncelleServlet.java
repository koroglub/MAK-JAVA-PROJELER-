package com.example.finalprojesi;

import java.sql.*;

import com.example.finalprojesi.Gorev_listesi;
import com.example.finalprojesi.Gorev_listesiVeri;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "GuncelleServlet", value = "/gorevGuncelle")
public class GuncelleServlet extends HttpServlet {

    private Gorev_listesiVeri gorevVeri =new Gorev_listesiVeri();
    //Veritabanı bağlantısı yapın
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Connection conn = null;
        Statement stmt = null;

        try {

            String gorev_ismi=request.getParameter("gorev_ismi");
            String gorev_aciklamasi=request.getParameter("gorev_aciklamasi");
            String onem_duzeyi=request.getParameter("onem_duzeyi");
            String durum=request.getParameter("durum");
            Gorev_listesi gorev1=new Gorev_listesi(gorev_ismi,gorev_aciklamasi,onem_duzeyi,durum);
            Class.forName("com.mysql.jdbc.Driver");
            conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/anasayfa", "username", "password");

// Güncelleme işlemini gerçekleştirin


            durum = request.getParameter("durum");

            stmt = conn.createStatement();


            String sql = "UPDATE gorev_listesi SET durum="+durum;
            stmt.executeUpdate(sql);

            response.sendRedirect("anasayfa.jsp");

// Güncelleme yapıldıktan sonra başka bir sayfaya yönlendirin
        }

        catch (Exception e) {
            throw new RuntimeException();
        }

        finally {


            try {
                if (stmt != null) {
                    stmt.close();
                }

                if (conn != null) {
                    conn.close();
                }
            }

            catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}